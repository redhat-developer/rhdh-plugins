"use strict";(()=>{(self.webpackChunkapp=self.webpackChunkapp||[]).push([[240,1645,3097,4026,5478],{31085:(h,o,n)=>{h.exports=n(73335)},51645:(h,o,n)=>{n.r(o),n.d(o,{ThemeProvider:()=>t,unstable_nested:()=>c,useTheme:()=>f});var m=n(89575),u=n(95478);const l=u.createContext(null);function f(){return u.useContext(l)}const c=typeof Symbol=="function"&&Symbol.for?Symbol.for("mui.nested"):"__THEME_NESTED__";var a=n(31085);function e(r,s){return typeof s=="function"?s(r):(0,m.A)({},r,s)}function _(r){const{children:s,theme:i}=r,p=f(),T=u.useMemo(()=>{const y=p===null?i:e(p,i);return y!=null&&(y[c]=p!==null),y},[i,p]);return(0,a.jsx)(l.Provider,{value:T,children:s})}const t=_;/**
 * @mui/private-theming v5.17.1
 *
 * @license MIT
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */},73335:(h,o,n)=>{/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var m=n(95478),u=Symbol.for("react.element"),d=Symbol.for("react.fragment"),l=Object.prototype.hasOwnProperty,f=m.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,v={key:!0,ref:!0,__self:!0,__source:!0};function c(a,e,_){var t,r={},s=null,i=null;_!==void 0&&(s=""+_),e.key!==void 0&&(s=""+e.key),e.ref!==void 0&&(i=e.ref);for(t in e)l.call(e,t)&&!v.hasOwnProperty(t)&&(r[t]=e[t]);if(a&&a.defaultProps)for(t in e=a.defaultProps,e)r[t]===void 0&&(r[t]=e[t]);return{$$typeof:u,type:a,key:s,ref:i,props:r,_owner:f.current}}o.Fragment=d,o.jsx=c,o.jsxs=c},89575:(h,o,n)=>{n.d(o,{A:()=>m});function m(){return m=Object.assign?Object.assign.bind():function(u){for(var d=1;d<arguments.length;d++){var l=arguments[d];for(var f in l)({}).hasOwnProperty.call(l,f)&&(u[f]=l[f])}return u},m.apply(null,arguments)}}}]);})();

//# sourceMappingURL=1645.ec852a70.chunk.js.map