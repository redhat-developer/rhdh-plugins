"use strict";(()=>{(self.webpackChunkapp=self.webpackChunkapp||[]).push([[240,3097,3860,4286,5478],{31085:(a,n,_)=>{a.exports=_(73335)},73335:(a,n,_)=>{/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var t=_(95478),p=Symbol.for("react.element"),u=Symbol.for("react.fragment"),o=Object.prototype.hasOwnProperty,s=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,k={key:!0,ref:!0,__self:!0,__source:!0};function i(l,e,d){var r,f={},c=null,b=null;d!==void 0&&(c=""+d),e.key!==void 0&&(c=""+e.key),e.ref!==void 0&&(b=e.ref);for(r in e)o.call(e,r)&&!k.hasOwnProperty(r)&&(f[r]=e[r]);if(l&&l.defaultProps)for(r in e=l.defaultProps,e)f[r]===void 0&&(f[r]=e[r]);return{$$typeof:p,type:l,key:c,ref:b,props:f,_owner:s.current}}n.Fragment=u,n.jsx=i,n.jsxs=i},89575:(a,n,_)=>{_.d(n,{A:()=>t});function t(){return t=Object.assign?Object.assign.bind():function(p){for(var u=1;u<arguments.length;u++){var o=arguments[u];for(var s in o)({}).hasOwnProperty.call(o,s)&&(p[s]=o[s])}return p},t.apply(null,arguments)}}}]);})();

//# sourceMappingURL=3860.c695f783.chunk.js.map