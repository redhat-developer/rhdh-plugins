"use strict";(()=>{(self.webpackChunkapp=self.webpackChunkapp||[]).push([[2131],{32131:(n,a,s)=>{s.r(a),s.d(a,{default:()=>l});var _=s(65001),e=s(27482);const l=(0,_.W)({ref:e.r,full:!1,messages:{sidebarTitle:"Settings"}})}}]);})();

//# sourceMappingURL=2131.d7b2d157.chunk.js.map